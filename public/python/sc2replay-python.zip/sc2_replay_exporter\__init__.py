"""SC2 replay parser demo exporter."""

__all__ = ["__version__"]
__version__ = "0.1.0"
