from __future__ import annotations

from collections import Counter
from copy import deepcopy

from .model import (
    CompositionSample,
    MutableReplayState,
    PlayerStats,
    StatsSample,
    TimelineEvent,
    UnitState,
)
from .normalizer import icon_name, pretty_name, time_point


def add_timeline(
    state: MutableReplayState,
    *,
    game_loop: int,
    player_id: int | None,
    kind: str,
    name: str,
    unit_tag: int | None = None,
    raw_event_type: str | None = None,
    extra: dict | None = None,
) -> None:
    state.timeline.append(
        TimelineEvent(
            time=time_point(game_loop),
            player_id=player_id,
            kind=kind,
            name=pretty_name(name),
            icon=icon_name(name),
            unit_tag=unit_tag,
            raw_event_type=raw_event_type,
            extra=extra or {},
        )
    )


def _counter_for_player(state: MutableReplayState, player_id: int) -> Counter[str]:
    if player_id not in state.alive_units_by_player:
        state.alive_units_by_player[player_id] = Counter()
    return state.alive_units_by_player[player_id]


def unit_started(
    state: MutableReplayState,
    *,
    game_loop: int,
    player_id: int | None,
    unit_tag: int,
    unit_type: str,
    raw_event_type: str = "UnitInitEvent",
) -> None:
    tp = time_point(game_loop)
    unit = state.units.get(unit_tag)
    if unit is None:
        unit = UnitState(unit_tag=unit_tag, owner_id=player_id, unit_type=unit_type)
        state.units[unit_tag] = unit
    unit.owner_id = player_id if player_id is not None else unit.owner_id
    unit.unit_type = unit_type or unit.unit_type
    unit.started_at = tp
    unit.status = "in_progress"
    add_timeline(
        state,
        game_loop=game_loop,
        player_id=player_id,
        kind="unit_started",
        name=unit_type,
        unit_tag=unit_tag,
        raw_event_type=raw_event_type,
    )


def unit_done(
    state: MutableReplayState,
    *,
    game_loop: int,
    unit_tag: int,
    unit_type: str | None = None,
    player_id: int | None = None,
    raw_event_type: str = "UnitDoneEvent",
) -> None:
    tp = time_point(game_loop)
    unit = state.units.get(unit_tag)
    if unit is None:
        unit = UnitState(unit_tag=unit_tag, owner_id=player_id, unit_type=unit_type or "Unknown")
        state.units[unit_tag] = unit
    if unit_type:
        unit.unit_type = unit_type
    if player_id is not None:
        unit.owner_id = player_id
    unit.done_at = tp
    unit.status = "alive"
    if unit.owner_id is not None:
        _counter_for_player(state, unit.owner_id)[unit.unit_type] += 1
    add_timeline(
        state,
        game_loop=game_loop,
        player_id=unit.owner_id,
        kind="unit_done",
        name=unit.unit_type,
        unit_tag=unit_tag,
        raw_event_type=raw_event_type,
    )


def unit_born(
    state: MutableReplayState,
    *,
    game_loop: int,
    player_id: int | None,
    unit_tag: int,
    unit_type: str,
    raw_event_type: str = "UnitBornEvent",
) -> None:
    tp = time_point(game_loop)
    unit = state.units.get(unit_tag)
    if unit is None:
        unit = UnitState(unit_tag=unit_tag, owner_id=player_id, unit_type=unit_type)
        state.units[unit_tag] = unit
    unit.owner_id = player_id if player_id is not None else unit.owner_id
    unit.unit_type = unit_type or unit.unit_type
    unit.born_at = tp
    unit.done_at = unit.done_at or tp
    unit.status = "alive"
    if unit.owner_id is not None:
        _counter_for_player(state, unit.owner_id)[unit.unit_type] += 1
    add_timeline(
        state,
        game_loop=game_loop,
        player_id=unit.owner_id,
        kind="unit_born",
        name=unit.unit_type,
        unit_tag=unit_tag,
        raw_event_type=raw_event_type,
    )


def unit_died(
    state: MutableReplayState,
    *,
    game_loop: int,
    unit_tag: int,
    player_id: int | None = None,
    unit_type: str | None = None,
    killer_player_id: int | None = None,
    raw_event_type: str = "UnitDiedEvent",
) -> None:
    tp = time_point(game_loop)
    unit = state.units.get(unit_tag)
    if unit is None:
        unit = UnitState(unit_tag=unit_tag, owner_id=player_id, unit_type=unit_type or "Unknown")
        state.units[unit_tag] = unit
    if unit_type:
        unit.unit_type = unit_type
    if player_id is not None:
        unit.owner_id = player_id
    unit.died_at = tp
    unit.status = "dead"
    if unit.owner_id is not None:
        counter = _counter_for_player(state, unit.owner_id)
        if counter[unit.unit_type] > 0:
            counter[unit.unit_type] -= 1
            if counter[unit.unit_type] <= 0:
                del counter[unit.unit_type]
    add_timeline(
        state,
        game_loop=game_loop,
        player_id=unit.owner_id,
        kind="unit_died",
        name=unit.unit_type,
        unit_tag=unit_tag,
        raw_event_type=raw_event_type,
        extra={"killer_player_id": killer_player_id},
    )


def unit_type_changed(
    state: MutableReplayState,
    *,
    game_loop: int,
    unit_tag: int,
    new_unit_type: str,
    player_id: int | None = None,
    raw_event_type: str = "UnitTypeChangeEvent",
) -> None:
    unit = state.units.get(unit_tag)
    old_type = unit.unit_type if unit else "Unknown"
    if unit is None:
        unit = UnitState(unit_tag=unit_tag, owner_id=player_id, unit_type=new_unit_type, status="alive")
        state.units[unit_tag] = unit
    owner = player_id if player_id is not None else unit.owner_id
    if owner is not None and unit.status == "alive":
        counter = _counter_for_player(state, owner)
        if counter[old_type] > 0:
            counter[old_type] -= 1
        counter[new_unit_type] += 1
    unit.owner_id = owner
    unit.unit_type = new_unit_type
    add_timeline(
        state,
        game_loop=game_loop,
        player_id=owner,
        kind="unit_type_changed",
        name=new_unit_type,
        unit_tag=unit_tag,
        raw_event_type=raw_event_type,
        extra={"old_type": old_type},
    )


def upgrade_done(
    state: MutableReplayState,
    *,
    game_loop: int,
    player_id: int | None,
    upgrade_name: str,
    raw_event_type: str = "UpgradeCompleteEvent",
) -> None:
    add_timeline(
        state,
        game_loop=game_loop,
        player_id=player_id,
        kind="upgrade_done",
        name=upgrade_name,
        raw_event_type=raw_event_type,
    )


def stats_sample(
    state: MutableReplayState,
    *,
    game_loop: int,
    stats: PlayerStats,
) -> None:
    state.latest_stats[stats.player_id] = stats
    state.samples.append(
        StatsSample(
            time=time_point(game_loop),
            players=deepcopy(state.latest_stats),
        )
    )
    state.composition.append(
        CompositionSample(
            time=time_point(game_loop),
            players={pid: dict(counter) for pid, counter in state.alive_units_by_player.items()},
        )
    )
