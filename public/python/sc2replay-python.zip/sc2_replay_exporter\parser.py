from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable

from .model import MutableReplayState, Player, PlayerStats, ReplayMeta
from .normalizer import safe_float, safe_int
from .state import (
    stats_sample,
    unit_born,
    unit_died,
    unit_done,
    unit_started,
    unit_type_changed,
    upgrade_done,
)


def _get(obj: Any, *names: str, default: Any = None) -> Any:
    for name in names:
        if hasattr(obj, name):
            value = getattr(obj, name)
            if value is not None:
                return value
    return default


def _event_name(event: Any) -> str:
    return str(_get(event, "name", default=event.__class__.__name__))


def _game_loop(event: Any) -> int:
    # sc2reader tracker.py stores event.frame; its old docs print event.time/second.
    return safe_int(_get(event, "frame", "frames", "game_loop", default=0))


def _unit_tag(event: Any) -> int | None:
    tag = _get(event, "unit_id", "unit_tag", default=None)
    if tag is not None:
        return safe_int(tag)
    index = _get(event, "unit_id_index", default=None)
    recycle = _get(event, "unit_id_recycle", default=None)
    if index is not None and recycle is not None:
        return (safe_int(index) << 18) | safe_int(recycle)
    unit = _get(event, "unit", default=None)
    return _get(unit, "id", "unit_id", default=None) if unit is not None else None


def _unit_type(event: Any) -> str:
    unit_type = _get(event, "unit_type_name", "unit_type", default=None)
    if isinstance(unit_type, bytes):
        return unit_type.decode("utf-8", errors="replace")
    if unit_type:
        return str(unit_type)
    unit = _get(event, "unit", default=None)
    if unit is not None:
        value = _get(unit, "name", "type", "unit_type_name", default=None)
        if value:
            return str(value)
    return "Unknown"


def _owner_pid(event: Any) -> int | None:
    for attr in ("upkeep_pid", "control_pid", "pid"):
        value = _get(event, attr, default=None)
        if value not in (None, 0):
            return safe_int(value)
    for attr in ("unit_upkeeper", "unit_controller", "player"):
        player = _get(event, attr, default=None)
        pid = _get(player, "pid", default=None) if player is not None else None
        if pid not in (None, 0):
            return safe_int(pid)
    unit = _get(event, "unit", default=None)
    owner = _get(unit, "owner", default=None) if unit is not None else None
    pid = _get(owner, "pid", default=None) if owner is not None else None
    return safe_int(pid) if pid not in (None, 0) else None


def _player_to_model(player: Any) -> Player:
    pid = safe_int(_get(player, "pid", "id", default=0))
    team = _get(_get(player, "team", default=None), "number", default=None)
    return Player(
        pid=pid,
        name=str(_get(player, "name", default=f"Player{pid}")),
        race=str(_get(player, "play_race", "pick_race", "race", default="Unknown")),
        result=str(_get(player, "result", default="Unknown")),
        team=safe_int(team) if team is not None else None,
    )


def _meta_from_replay(path: Path, replay: Any) -> ReplayMeta:
    release = _get(replay, "release_string", "release", "game_version", default="Unknown")
    return ReplayMeta(
        file=path.name,
        map_name=str(_get(replay, "map_name", "map", default="Unknown")),
        game_version=str(release),
        base_build=safe_int(_get(replay, "build", "base_build", default=0)) or None,
        duration_seconds=safe_float(_get(_get(replay, "length", default=None), "seconds", default=None), default=None),
        speed=str(_get(replay, "speed", default="Unknown")),
    )


def _stats_from_event(event: Any) -> PlayerStats:
    pid = safe_int(_get(event, "pid", default=0))
    return PlayerStats(
        player_id=pid,
        food_used=safe_float(_get(event, "food_used", default=0)),
        food_cap=safe_float(_get(event, "food_made", "food_cap", default=0)),
        workers=safe_int(_get(event, "workers_active_count", "workers", default=0)),
        minerals=safe_int(_get(event, "minerals_current", default=0)),
        vespene=safe_int(_get(event, "vespene_current", default=0)),
        minerals_collection_rate=safe_int(_get(event, "minerals_collection_rate", default=0)),
        vespene_collection_rate=safe_int(_get(event, "vespene_collection_rate", default=0)),
        army_minerals=safe_int(_get(event, "minerals_used_current_army", "minerals_used_active_forces", default=0)),
        army_vespene=safe_int(_get(event, "vespene_used_current_army", "vespene_used_active_forces", default=0)),
    )


def parse_replay(path: str | Path) -> MutableReplayState:
    """Parse a real .SC2Replay file through sc2reader.

    The implementation intentionally uses dynamic attribute access because sc2reader event
    shapes differ slightly across replay versions. Unknown events are skipped instead of
    failing the whole export.
    """
    replay_path = Path(path)
    try:
        import sc2reader  # type: ignore
    except ImportError as exc:
        raise RuntimeError("缺少 sc2reader，请先执行：pip install -r requirements.txt") from exc

    replay = sc2reader.load_replay(str(replay_path), load_level=4)
    state = MutableReplayState(meta=_meta_from_replay(replay_path, replay))

    for player in getattr(replay, "players", []) or []:
        model = _player_to_model(player)
        if model.pid:
            state.players[model.pid] = model

    events: Iterable[Any] = getattr(replay, "events", []) or []
    for event in events:
        name = _event_name(event)
        game_loop = _game_loop(event)

        if name == "PlayerStatsEvent":
            stats = _stats_from_event(event)
            if stats.player_id:
                stats_sample(state, game_loop=game_loop, stats=stats)
            continue

        if name == "UnitInitEvent":
            tag = _unit_tag(event)
            if tag is not None:
                unit_started(
                    state,
                    game_loop=game_loop,
                    player_id=_owner_pid(event),
                    unit_tag=tag,
                    unit_type=_unit_type(event),
                    raw_event_type=name,
                )
            continue

        if name == "UnitDoneEvent":
            tag = _unit_tag(event)
            if tag is not None:
                unit_done(
                    state,
                    game_loop=game_loop,
                    unit_tag=tag,
                    unit_type=_unit_type(event),
                    player_id=_owner_pid(event),
                    raw_event_type=name,
                )
            continue

        if name == "UnitBornEvent":
            tag = _unit_tag(event)
            if tag is not None:
                unit_born(
                    state,
                    game_loop=game_loop,
                    player_id=_owner_pid(event),
                    unit_tag=tag,
                    unit_type=_unit_type(event),
                    raw_event_type=name,
                )
            continue

        if name == "UnitDiedEvent":
            tag = _unit_tag(event)
            if tag is not None:
                unit_died(
                    state,
                    game_loop=game_loop,
                    unit_tag=tag,
                    player_id=_owner_pid(event),
                    unit_type=_unit_type(event),
                    killer_player_id=safe_int(_get(event, "killing_player_id", "killer_pid", default=0)) or None,
                    raw_event_type=name,
                )
            continue

        if name == "UnitTypeChangeEvent":
            tag = _unit_tag(event)
            if tag is not None:
                unit_type_changed(
                    state,
                    game_loop=game_loop,
                    unit_tag=tag,
                    new_unit_type=_unit_type(event),
                    player_id=_owner_pid(event),
                    raw_event_type=name,
                )
            continue

        if name in {"UpgradeCompleteEvent", "SUpgradeEvent", "UpgradeEvent"}:
            upgrade = _get(event, "upgrade_type_name", "upgrade_name", "upgrade", default="UnknownUpgrade")
            if isinstance(upgrade, bytes):
                upgrade = upgrade.decode("utf-8", errors="replace")
            upgrade_done(
                state,
                game_loop=game_loop,
                player_id=safe_int(_get(event, "pid", default=0)) or _owner_pid(event),
                upgrade_name=str(upgrade),
                raw_event_type=name,
            )

    return state
