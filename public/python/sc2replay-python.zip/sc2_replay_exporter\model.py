from __future__ import annotations

from collections import Counter
from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(slots=True)
class TimePoint:
    game_loop: int
    second: float
    time: str


@dataclass(slots=True)
class Player:
    pid: int
    name: str
    race: str = "Unknown"
    result: str = "Unknown"
    team: int | None = None


@dataclass(slots=True)
class ReplayMeta:
    file: str
    map_name: str = "Unknown"
    game_version: str = "Unknown"
    base_build: int | None = None
    duration_seconds: float | None = None
    speed: str = "Unknown"


@dataclass(slots=True)
class TimelineEvent:
    time: TimePoint
    player_id: int | None
    kind: str
    name: str
    icon: str | None = None
    unit_tag: int | None = None
    raw_event_type: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class UnitState:
    unit_tag: int
    owner_id: int | None
    unit_type: str
    started_at: TimePoint | None = None
    born_at: TimePoint | None = None
    done_at: TimePoint | None = None
    died_at: TimePoint | None = None
    status: str = "unknown"


@dataclass(slots=True)
class PlayerStats:
    player_id: int
    food_used: float = 0
    food_cap: float = 0
    workers: int = 0
    minerals: int = 0
    vespene: int = 0
    minerals_collection_rate: int = 0
    vespene_collection_rate: int = 0
    army_minerals: int = 0
    army_vespene: int = 0


@dataclass(slots=True)
class StatsSample:
    time: TimePoint
    players: dict[int, PlayerStats]


@dataclass(slots=True)
class CompositionSample:
    time: TimePoint
    players: dict[int, dict[str, int]]


@dataclass(slots=True)
class ReplayExport:
    meta: ReplayMeta
    players: list[Player]
    timeline: list[TimelineEvent]
    samples: list[StatsSample]
    composition: list[CompositionSample]
    units: list[UnitState]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class MutableReplayState:
    meta: ReplayMeta
    players: dict[int, Player] = field(default_factory=dict)
    timeline: list[TimelineEvent] = field(default_factory=list)
    latest_stats: dict[int, PlayerStats] = field(default_factory=dict)
    samples: list[StatsSample] = field(default_factory=list)
    composition: list[CompositionSample] = field(default_factory=list)
    units: dict[int, UnitState] = field(default_factory=dict)
    alive_units_by_player: dict[int, Counter[str]] = field(default_factory=dict)

    def to_export(self) -> ReplayExport:
        # PlayerStatsEvent normally arrives once per player at the same timestamp.
        # Merge same-timestamp samples so JSON/Markdown are easier for the editor to consume.
        merged_samples: dict[int, StatsSample] = {}
        for sample in self.samples:
            key = sample.time.game_loop
            if key not in merged_samples:
                merged_samples[key] = StatsSample(time=sample.time, players={})
            merged_samples[key].players.update(sample.players)

        merged_composition: dict[int, CompositionSample] = {}
        for sample in self.composition:
            key = sample.time.game_loop
            if key not in merged_composition:
                merged_composition[key] = CompositionSample(time=sample.time, players={})
            merged_composition[key].players.update(sample.players)

        return ReplayExport(
            meta=self.meta,
            players=sorted(self.players.values(), key=lambda p: p.pid),
            timeline=sorted(self.timeline, key=lambda e: (e.time.game_loop, e.player_id or 0, e.kind, e.name)),
            samples=[merged_samples[k] for k in sorted(merged_samples)],
            composition=[merged_composition[k] for k in sorted(merged_composition)],
            units=sorted(self.units.values(), key=lambda u: u.unit_tag),
        )
