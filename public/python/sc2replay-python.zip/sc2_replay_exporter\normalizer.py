from __future__ import annotations

import re

GAME_LOOPS_PER_SECOND = 22.4

_COMPOUND_ALIASES = {
    "supplydepot": "supply-depot",
    "commandcenter": "command-center",
    "engineeringbay": "engineering-bay",
    "missileturret": "missile-turret",
    "sensortower": "sensor-tower",
    "ghostacademy": "ghost-academy",
    "factorytechlab": "tech-lab",
    "barrackstechlab": "tech-lab",
    "starporttechlab": "tech-lab",
    "reactor": "reactor",
    "battlecruiser": "battle-cruiser",
    "siegetank": "siege-tank",
    "widowmine": "widow-mine",
    "vikingfighter": "viking-fighter",
    "hellionbattlemode": "hellion-battle-mode",
    "cyberneticscore": "cybernetics-core",
    "twilightcouncil": "twilight-council",
    "templararchives": "templar-archives",
    "darkshrine": "dark-shrine",
    "roboticsfacility": "robotics-facility",
    "roboticssupportbay": "robotics-support-bay",
    "fleetbeacon": "fleet-beacon",
    "photoncanon": "photon-cannon",
    "photoncannon": "photon-cannon",
    "shieldbattery": "shield-battery",
    "hightemplar": "high-templar",
    "darktemplar": "dark-templar",
    "warpprism": "warp-prism",
    "warpgate": "warp-gate",
    "spawningpool": "spawning-pool",
    "banelingnest": "baneling-nest",
    "roachwarren": "roach-warren",
    "hydraliskden": "hydralisk-den",
    "infestationpit": "infestation-pit",
    "spire": "spire",
    "greaterspire": "greater-spire",
    "ultraliskcavern": "ultralisk-cavern",
    "evolutionchamber": "evolution-chamber",
    "nydusnetwork": "nydus-network",
    "nydusworm": "nydus-worm",
    "spinecrawler": "spine-crawler",
    "sporecrawler": "spore-crawler",
    "broodlord": "brood-lord",
    "swarmhost": "swarm-host",
    "lurkerden": "lurker-den",
    "stimpack": "stimpack",
    "combatshield": "combat-shield",
    "yamato": "yamato-gun",
    "psistorm": "psi-storm",
    "neuralparasite": "neural-parasite",
    # SC2 internal upgrade names that differ from icon file names.
    # Stripped (no spaces, lowercase) form -> correct icon alias.
    "glialreconstitution": "glialreconstitution",
    "zerggroundarmorslevel1": "ground-carapace-level-1",
    "zerggroundarmorslevel2": "ground-carapace-level-2",
    "zerggroundarmorslevel3": "ground-carapace-level-3",
    "zergmissileweaponslevel1": "missile-attacks-level-1",
    "zergmissileweaponslevel2": "missile-attacks-level-2",
    "zergmissileweaponslevel3": "missile-attacks-level-3",
    "zerglingmovementspeed": "metabolicboost",
}

_NOISE_SUFFIXES = ("flying", "lowered", "burrowed", "sieged", "unsieged")


def game_loop_to_seconds(game_loop: int) -> float:
    return round(game_loop / GAME_LOOPS_PER_SECOND, 2)


def format_time(seconds: float) -> str:
    total = int(round(seconds))
    minutes, sec = divmod(total, 60)
    hours, minutes = divmod(minutes, 60)
    if hours:
        return f"{hours:02d}:{minutes:02d}:{sec:02d}"
    return f"{minutes:02d}:{sec:02d}"


def time_point(game_loop: int):
    from .model import TimePoint

    second = game_loop_to_seconds(game_loop)
    return TimePoint(game_loop=game_loop, second=second, time=format_time(second))


def split_camel(value: str) -> str:
    # Keep acronyms such as SCV and ID intact, but split SupplyDepot -> Supply Depot.
    value = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", value)
    value = re.sub(r"(?<=[A-Z])(?=[A-Z][a-z])", " ", value)
    return value.strip()


def pretty_name(value: str | None) -> str:
    if not value:
        return "Unknown"
    value = str(value).replace("_", " ").replace("-", " ").strip()
    if " " not in value:
        value = split_camel(value)
    return re.sub(r"\s+", " ", value).strip()


def icon_name(value: str | None) -> str:
    if not value:
        return "unknown"
    raw = str(value)
    raw = re.sub(r"[^a-zA-Z0-9]+", "", raw).lower()
    for suffix in _NOISE_SUFFIXES:
        if raw.endswith(suffix):
            raw = raw[: -len(suffix)]
    if raw in _COMPOUND_ALIASES:
        return _COMPOUND_ALIASES[raw]
    kebab = re.sub(r"([a-z0-9])([A-Z])", r"\1-\2", str(value)).lower()
    kebab = re.sub(r"[^a-z0-9]+", "-", kebab).strip("-")
    return _COMPOUND_ALIASES.get(kebab.replace("-", ""), kebab)


def safe_int(value, default: int = 0) -> int:
    try:
        if value is None:
            return default
        return int(value)
    except Exception:
        return default


def safe_float(value, default: float = 0) -> float:
    try:
        if value is None:
            return default
        return float(value)
    except Exception:
        return default
