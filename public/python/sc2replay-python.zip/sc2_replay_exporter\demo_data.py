from __future__ import annotations

from .model import MutableReplayState, Player, PlayerStats, ReplayMeta
from .state import stats_sample, unit_born, unit_died, unit_done, unit_started, upgrade_done


def build_demo_state() -> MutableReplayState:
    state = MutableReplayState(
        meta=ReplayMeta(
            file="demo.SC2Replay",
            map_name="Demo Map LE",
            game_version="demo-5.x",
            base_build=99999,
            duration_seconds=420,
            speed="Faster",
        )
    )
    state.players[1] = Player(pid=1, name="DemoTerran", race="Terran", result="Win", team=1)
    state.players[2] = Player(pid=2, name="DemoZerg", race="Zerg", result="Loss", team=2)

    # 初始单位
    for i in range(12):
        unit_born(state, game_loop=0, player_id=1, unit_tag=1000 + i, unit_type="SCV")
        unit_born(state, game_loop=0, player_id=2, unit_tag=2000 + i, unit_type="Drone")
    unit_born(state, game_loop=0, player_id=1, unit_tag=1100, unit_type="CommandCenter")
    unit_born(state, game_loop=0, player_id=2, unit_tag=2100, unit_type="Hatchery")

    # Terran build order
    unit_started(state, game_loop=14 * 22, player_id=1, unit_tag=1200, unit_type="SupplyDepot")
    unit_done(state, game_loop=36 * 22, unit_tag=1200)
    unit_started(state, game_loop=46 * 22, player_id=1, unit_tag=1201, unit_type="Barracks")
    unit_done(state, game_loop=111 * 22, unit_tag=1201)
    unit_started(state, game_loop=130 * 22, player_id=1, unit_tag=1202, unit_type="Refinery")
    unit_done(state, game_loop=151 * 22, unit_tag=1202)
    unit_born(state, game_loop=147 * 22, player_id=1, unit_tag=1300, unit_type="Marine")
    unit_born(state, game_loop=168 * 22, player_id=1, unit_tag=1301, unit_type="Marine")
    unit_started(state, game_loop=190 * 22, player_id=1, unit_tag=1203, unit_type="Factory")
    unit_done(state, game_loop=253 * 22, unit_tag=1203)
    upgrade_done(state, game_loop=300 * 22, player_id=1, upgrade_name="Stimpack")

    # Zerg side
    unit_started(state, game_loop=44 * 22, player_id=2, unit_tag=2200, unit_type="SpawningPool")
    unit_done(state, game_loop=110 * 22, unit_tag=2200)
    unit_born(state, game_loop=132 * 22, player_id=2, unit_tag=2300, unit_type="Zergling")
    unit_born(state, game_loop=132 * 22, player_id=2, unit_tag=2301, unit_type="Zergling")
    unit_born(state, game_loop=132 * 22, player_id=2, unit_tag=2302, unit_type="Zergling")
    unit_born(state, game_loop=132 * 22, player_id=2, unit_tag=2303, unit_type="Zergling")
    unit_started(state, game_loop=160 * 22, player_id=2, unit_tag=2201, unit_type="RoachWarren")
    unit_done(state, game_loop=199 * 22, unit_tag=2201)
    unit_born(state, game_loop=230 * 22, player_id=2, unit_tag=2304, unit_type="Roach")
    unit_born(state, game_loop=230 * 22, player_id=2, unit_tag=2305, unit_type="Roach")
    unit_died(state, game_loop=320 * 22, unit_tag=2300, killer_player_id=1)
    unit_died(state, game_loop=321 * 22, unit_tag=2301, killer_player_id=1)

    # 经济/人口采样，模拟 PlayerStatsEvent
    for seconds, p1, p2 in [
        (0, (12, 15, 12, 50, 0), (12, 14, 12, 50, 0)),
        (60, (15, 23, 14, 180, 0), (16, 22, 15, 160, 0)),
        (120, (20, 31, 18, 240, 40), (24, 28, 20, 220, 20)),
        (180, (28, 39, 23, 320, 90), (34, 36, 28, 260, 80)),
        (240, (38, 46, 30, 410, 120), (44, 50, 34, 180, 120)),
        (300, (51, 62, 38, 520, 180), (58, 66, 42, 300, 160)),
        (360, (66, 78, 46, 640, 220), (61, 74, 44, 260, 190)),
    ]:
        gl = seconds * 22
        stats_sample(
            state,
            game_loop=gl,
            stats=PlayerStats(
                player_id=1,
                food_used=p1[0],
                food_cap=p1[1],
                workers=p1[2],
                minerals=p1[3],
                vespene=p1[4],
                minerals_collection_rate=850 + seconds,
                vespene_collection_rate=180,
                army_minerals=200 + seconds,
                army_vespene=40,
            ),
        )
        stats_sample(
            state,
            game_loop=gl,
            stats=PlayerStats(
                player_id=2,
                food_used=p2[0],
                food_cap=p2[1],
                workers=p2[2],
                minerals=p2[3],
                vespene=p2[4],
                minerals_collection_rate=830 + seconds,
                vespene_collection_rate=160,
                army_minerals=220 + seconds,
                army_vespene=30,
            ),
        )

    return state
