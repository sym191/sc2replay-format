from __future__ import annotations

import json
from collections import Counter
from dataclasses import asdict
from pathlib import Path
from typing import Any, Iterable

from .model import CompositionSample, PlayerStats, ReplayExport, StatsSample, TimelineEvent
from .normalizer import format_time

# Only build-queue events: production (workers, combat units), buildings, and upgrades.
# Excludes unit_died (combat losses) and unit_type_changed (morphs/mode switches).
IMPORTANT_TIMELINE_KINDS = {
    "unit_started",
    "unit_done",
    "unit_born",
    "upgrade_done",
}

# Units that spawn automatically (not produced via player build commands).
# These should not appear in the build queue timeline.
_NON_PLAYER_UNITS = {
    # Zerg auto-spawn
    "Larva",
    "Broodling",
    "Locust",
    "Infested Terran",
    "Changeling",
    "Changeling Zergling Wings",
    # Zerg morph intermediates (auto-created during morph)
    "Egg",
    "Overlord Cocoon",
    "Ravager Cocoon",
    # Creep tumors (initial is player-placed, but auto-spread ones are indistinguishable)
    "Creep Tumor",
    "Creep Tumor Burrowed",
    "Creep Tumor Queen",
    # Map critters
    "Carrion Bird",
    "Dog",
    "Sheep",
}

# Unit name prefixes that indicate non-player entities (map objects, beacons, etc.).
_NON_PLAYER_PREFIXES = (
    "Beacon ",
    "Reward ",
    "Mineral Field",
    "Vespene Geyser",
    "Destructible Rock",
    "Unbuildable Rocks",
    "Spray ",
)


def _is_non_player_unit(name: str) -> bool:
    if name in _NON_PLAYER_UNITS:
        return True
    return name.startswith(_NON_PLAYER_PREFIXES)
WORKER_UNITS = {"SCV", "Probe", "Drone", "MULE"}
UNIT_FOOD = {
    # Terran
    "SCV": 1,
    "Marine": 1,
    "Marauder": 2,
    "Reaper": 1,
    "Ghost": 2,
    "Hellion": 2,
    "Hellbat": 2,
    "WidowMine": 2,
    "SiegeTank": 3,
    "Cyclone": 3,
    "Thor": 6,
    "VikingFighter": 2,
    "VikingAssault": 2,
    "Medivac": 2,
    "Liberator": 3,
    "Raven": 2,
    "Banshee": 3,
    "Battlecruiser": 6,
    # Protoss
    "Probe": 1,
    "Zealot": 2,
    "Stalker": 2,
    "Sentry": 2,
    "Adept": 2,
    "HighTemplar": 2,
    "DarkTemplar": 2,
    "Immortal": 4,
    "Colossus": 6,
    "Disruptor": 3,
    "Archon": 4,
    "Observer": 1,
    "WarpPrism": 2,
    "Phoenix": 2,
    "VoidRay": 4,
    "Oracle": 3,
    "Tempest": 5,
    "Carrier": 6,
    "Mothership": 8,
    # Zerg
    "Drone": 1,
    "Queen": 2,
    "Zergling": 0.5,
    "Baneling": 0.5,
    "Roach": 2,
    "Ravager": 3,
    "Hydralisk": 2,
    "Lurker": 3,
    "Infestor": 2,
    "SwarmHost": 3,
    "Mutalisk": 2,
    "Corruptor": 2,
    "Viper": 3,
    "Ultralisk": 6,
    "BroodLord": 4,
    "Overlord": 0,
    "Overseer": 0,
}


def _icon_for_name(name: str) -> str:
    from .normalizer import icon_name

    return icon_name(name)


def _top_unit_items(composition: dict[str, int], limit: int = 12) -> str:
    items = sorted(composition.items(), key=lambda kv: (-kv[1], kv[0]))[:limit]
    if not items:
        return "-"
    return ", ".join(f"/icon:{_icon_for_name(name)} {name} x{count}" for name, count in items if count > 0)


def _format_number(value: float | int) -> str:
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return f"{value:g}"


def _as_raw_unit_name(display_name: str) -> str:
    return display_name.replace(" ", "")


def _event_operation_key(event: TimelineEvent) -> tuple[str, str, str]:
    return (event.kind, event.name, event.icon or _icon_for_name(event.name))


def _format_operation(kind: str, name: str, icon: str, count: int) -> str:
    icon_text = f"/icon:{icon}" if icon else ""
    if count <= 0:
        return "-"
    if count <= 3:
        return " ".join(icon_text for _ in range(count)).strip()
    return f"{icon_text} × {count}"


def _group_events_within_one_second(events: list[TimelineEvent]) -> list[list[TimelineEvent]]:
    if not events:
        return []
    groups: list[list[TimelineEvent]] = []
    current: list[TimelineEvent] = [events[0]]
    last_second = events[0].time.second
    for event in events[1:]:
        if event.time.second - last_second <= 1.0:
            current.append(event)
        else:
            groups.append(current)
            current = [event]
        last_second = event.time.second
    groups.append(current)
    return groups


def _latest_stats_at(samples: list[StatsSample], player_id: int, second: float) -> PlayerStats | None:
    latest: PlayerStats | None = None
    for sample in samples:
        if sample.time.second <= second and player_id in sample.players:
            latest = sample.players[player_id]
        if sample.time.second > second:
            break
    return latest


def _latest_composition_at(samples: list[CompositionSample], player_id: int, second: float) -> dict[str, int]:
    latest: dict[str, int] = {}
    for sample in samples:
        if sample.time.second <= second and player_id in sample.players:
            latest = sample.players[player_id]
        if sample.time.second > second:
            break
    return latest


def _estimate_food_from_composition(composition: dict[str, int]) -> tuple[float, float]:
    worker_food = 0.0
    army_food = 0.0
    for unit_name, count in composition.items():
        raw_name = _as_raw_unit_name(unit_name)
        food = UNIT_FOOD.get(raw_name, 0)
        if raw_name in WORKER_UNITS:
            worker_food += food * count
        else:
            army_food += food * count
    return worker_food, army_food


def _population_cells(export: ReplayExport, player_id: int, second: float) -> tuple[str, str]:
    stats = _latest_stats_at(export.samples, player_id, second)
    composition = _latest_composition_at(export.composition, player_id, second)
    if stats is not None:
        worker_food = float(stats.workers)
        army_food = max(float(stats.food_used) - worker_food, 0.0)
        composition_cell = f"{_format_number(worker_food)}/{_format_number(army_food)}"
        population_cell = f"{_format_number(stats.food_used)}/{_format_number(stats.food_cap)}"
        return composition_cell, population_cell

    worker_food, army_food = _estimate_food_from_composition(composition)
    if worker_food or army_food:
        return f"{_format_number(worker_food)}/{_format_number(army_food)}", "-"
    return "-", "-"


def _build_player_timeline_table(export: ReplayExport, player_id: int) -> list[str]:
    events = [
        event
        for event in export.timeline
        if event.player_id == player_id
        and event.kind in IMPORTANT_TIMELINE_KINDS
        and event.time.second > 0  # skip initial game state at 00:00
        and not _is_non_player_unit(event.name)
    ]
    events.sort(key=lambda e: (e.time.second, e.kind, e.name))

    lines: list[str] = []
    lines.append("| 时间 | 操作 | 人口组成 工人/部队 | 当前人口/总可用人口 |")
    lines.append("|---|---|---:|---:|")

    for group in _group_events_within_one_second(events):
        display_second = group[0].time.second
        display_time = format_time(display_second)
        counter: Counter[tuple[str, str, str]] = Counter(_event_operation_key(event) for event in group)
        operations = [
            _format_operation(kind, name, icon, count)
            for (kind, name, icon), count in sorted(counter.items(), key=lambda item: (item[0][0], item[0][1]))
        ]
        composition_cell, population_cell = _population_cells(export, player_id, group[-1].time.second)
        lines.append(f"| {display_time} | {'; '.join(operations)} | {composition_cell} | {population_cell} |")

    if not events:
        lines.append("| - | - | - | - |")
    return lines


def build_editor_markdown(export: ReplayExport) -> str:
    players = {p.pid: p for p in export.players}
    lines: list[str] = []
    lines.append(f"# SC2 Replay 解析结果：{export.meta.map_name}")
    lines.append("")
    lines.append("## 基础信息")
    lines.append("")
    lines.append("| 字段 | 值 |")
    lines.append("|---|---|")
    lines.append(f"| 文件 | `{export.meta.file}` |")
    lines.append(f"| 地图 | {export.meta.map_name} |")
    lines.append(f"| 版本 | {export.meta.game_version} |")
    lines.append(f"| Base Build | {export.meta.base_build or '-'} |")
    lines.append(f"| 时长 | {export.meta.duration_seconds or '-'} 秒 |")
    lines.append(f"| 速度 | {export.meta.speed} |")
    lines.append("")

    lines.append("## 玩家")
    lines.append("")
    lines.append("| Player | 名称 | 种族 | 结果 | Team |")
    lines.append("|---|---|---|---|---|")
    for p in export.players:
        race_icon = f"/icon:{p.race.lower()}" if p.race and p.race != "Unknown" else ""
        lines.append(f"| P{p.pid} | {p.name} | {race_icon} {p.race} | {p.result} | {p.team or '-'} |")
    lines.append("")

    lines.append("## 建造 / 训练 / 升级时间线")
    lines.append("")
    lines.append("> 时间线按玩家拆分。相邻操作间隔 ≤ 1 秒时合并到同一个时间戳；同时间戳同操作重复 ≤ 3 次时展示多个图标，超过 3 次展示 `/icon:name × n`。")
    lines.append("")
    for p in export.players:
        lines.append(f"### P{p.pid} {p.name}")
        lines.append("")
        lines.extend(_build_player_timeline_table(export, p.pid))
        lines.append("")

    lines.append("## 人口 / 资源采样")
    lines.append("")
    lines.append("| 时间 | 玩家 | 人口 | 工人 | 晶矿 | 瓦斯 | 采矿速率 | 采气速率 | 军队价值 |")
    lines.append("|---|---:|---:|---:|---:|---:|---:|---:|---:|")
    for sample in export.samples:
        for pid, stats in sorted(sample.players.items()):
            army_value = stats.army_minerals + stats.army_vespene
            lines.append(
                f"| {sample.time.time} | P{pid} | {stats.food_used:g}/{stats.food_cap:g} | "
                f"{stats.workers} | {stats.minerals} | {stats.vespene} | "
                f"{stats.minerals_collection_rate} | {stats.vespene_collection_rate} | {army_value} |"
            )
    lines.append("")

    lines.append("## 单位组成快照")
    lines.append("")
    lines.append("| 时间 | 玩家 | 单位组成 |")
    lines.append("|---|---:|---|")
    for sample in export.composition:
        for pid, composition in sorted(sample.players.items()):
            player_name = players.get(pid).name if pid in players else f"P{pid}"
            lines.append(f"| {sample.time.time} | P{pid} {player_name} | {_top_unit_items(composition)} |")
    lines.append("")

    lines.append("## 给前端可视化的建议")
    lines.append("")
    lines.append("- `timeline`：现在建议前端也按玩家拆成独立轨道或独立表格展示。")
    lines.append("- `samples`：做人口、资源、工人、军队价值折线图。")
    lines.append("- `composition`：做单位组成堆叠图。")
    lines.append("- 图标语法统一使用 `/icon:name`，适配当前 `icon-md-editor`。")
    lines.append("")
    return "\n".join(lines)


def build_editor_document(export: ReplayExport) -> dict[str, Any]:
    return {
        "schema": "icon-md-editor.sc2-replay-document.v2",
        "title": f"SC2 Replay - {export.meta.map_name}",
        "markdown": build_editor_markdown(export),
        "data": export.to_dict(),
        "timeline_view": build_timeline_view(export),
    }


def build_timeline_view(export: ReplayExport) -> dict[str, Any]:
    """Structured player-split timeline for a future editor import path."""
    view: dict[str, Any] = {"grouping_window_seconds": 1.0, "players": {}}
    for player in export.players:
        rows: list[dict[str, Any]] = []
        events = [
            event
            for event in export.timeline
            if event.player_id == player.pid
            and event.kind in IMPORTANT_TIMELINE_KINDS
            and event.time.second > 0
            and not _is_non_player_unit(event.name)
        ]
        events.sort(key=lambda e: (e.time.second, e.kind, e.name))
        for group in _group_events_within_one_second(events):
            operation_counts: Counter[tuple[str, str, str]] = Counter(_event_operation_key(event) for event in group)
            composition_cell, population_cell = _population_cells(export, player.pid, group[-1].time.second)
            rows.append(
                {
                    "time": format_time(group[0].time.second),
                    "second": group[0].time.second,
                    "operations": [
                        {"kind": kind, "name": name, "icon": icon, "count": count}
                        for (kind, name, icon), count in sorted(operation_counts.items())
                    ],
                    "worker_army_food": composition_cell,
                    "food_used_cap": population_cell,
                }
            )
        view["players"][str(player.pid)] = {"name": player.name, "rows": rows}
    return view


def write_export_files(export: ReplayExport, out_dir: str | Path) -> None:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    def dump_json(name: str, data: Any) -> None:
        (out / name).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    dump_json("replay_meta.json", {"meta": asdict(export.meta), "players": [asdict(p) for p in export.players]})
    dump_json("timeline.json", [asdict(e) for e in export.timeline])
    dump_json("samples.json", [asdict(s) for s in export.samples])
    dump_json("composition.json", [asdict(c) for c in export.composition])

    timeline_view = build_timeline_view(export)
    dump_json("editor_timeline_view.json", timeline_view)

    editor_doc = build_editor_document(export)
    dump_json("editor_document.json", editor_doc)
    (out / "editor_document.md").write_text(editor_doc["markdown"], encoding="utf-8")
