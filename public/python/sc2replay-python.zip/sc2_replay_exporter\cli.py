from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .demo_data import build_demo_state
from .editor_formatter import write_export_files
from .parser import parse_replay


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Parse SC2Replay and export icon-md-editor compatible documents.")
    parser.add_argument("replay", nargs="?", help="Path to .SC2Replay. Omit when using --demo.")
    parser.add_argument("--demo", action="store_true", help="Use built-in fake replay events for smoke testing.")
    parser.add_argument("--out", default="output", help="Output directory. Default: output")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)

    if args.demo:
        state = build_demo_state()
    else:
        if not args.replay:
            print("error: 请传入 .SC2Replay 路径，或者使用 --demo", file=sys.stderr)
            return 2
        replay_path = Path(args.replay)
        if not replay_path.exists():
            print(f"error: replay 文件不存在：{replay_path}", file=sys.stderr)
            return 2
        state = parse_replay(replay_path)

    export = state.to_export()
    write_export_files(export, args.out)
    print(f"OK: exported {len(export.timeline)} timeline events, {len(export.samples)} stat samples")
    print(f"Output: {Path(args.out).resolve()}")
    print(f"Editor Markdown: {(Path(args.out) / 'editor_document.md').resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
